#include <stdio.h>
#include <string.h>
#include <ctype.h>

void left(char word[]);
void right(char word[]);
void inc(char word[]);
void dec(char word[]);

int main() {

   return 0;
}

void left(char word[]) {
   
}

void right(char word[]) {
   
}

void inc(char word[]) {
   
}

void dec(char word[]) {
   
}
